export const homeconfiguration = {
		home : {
		heading : 'A FREE AND SIMPLE LANDING PAGE',
		headingtext : 'Namari is a free landing page template you can use for your projects. It is free to use for your personal and commercial projects, enjoy!',
		buttontext : 'START CREATING TODAY',
		buttonlink : '\Home'
	}
}